import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import PyPDF2
import pytesseract
from PIL import Image

pytesseract.pytesseract.tesseract_cmd = r"C:\Users\nabil\Downloads\tesseract (2).exe"
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Windows only (if needed)
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def extract_text(file_path):
    ext = os.path.splitext(file_path.lower())[1]
    print("Processing file:", file_path)

    if ext == ".pdf":
        text = ""
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text() or ""
        return text

    elif ext in [".png", ".jpg", ".jpeg"]:
        try:
            image = Image.open(file_path)
            config = r"--psm 6 --oem 3"
            return pytesseract.image_to_string(image, config=config)
        except Exception as e:
            print("OCR ERROR FULL:", repr(e))
            raise e

    else:
        return "Unsupported file type"

@app.route("/extract-text", methods=["POST"])
def extract_text_api():
    print("Request received")

    if "file" not in request.files:
        print("No file in request")
        return jsonify({"error": "No file"}), 400

    file = request.files["file"]
    print("Filename:", file.filename)
    print("Mimetype:", file.mimetype)

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    text = extract_text(file_path)

    os.remove(file_path)

    return jsonify({"text": text})

if __name__ == "__main__":
    app.run(port=8000, debug=True)
