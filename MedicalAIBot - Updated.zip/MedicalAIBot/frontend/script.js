console.log("Script loaded");

const chatWindow = document.getElementById("chatWindow");
const promptInput = document.getElementById("promptInput");
const sendBtn = document.getElementById("sendBtn");
const fileInput = document.getElementById("fileInput");
const docStatus = document.getElementById("docStatus");

let extractedText = null;
let chatHistory = [];

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerText = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

sendBtn.addEventListener("click", sendMessage);
promptInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  addMessage("assistant", "Uploading and extracting document...");
  docStatus.innerText = "Uploading...";

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("http://127.0.0.1:8000/extract-text", {
      method: "POST",
      body: formData
    });

    const data = await res.json();

    extractedText = data.text;

    docStatus.innerText = "Document processed ✅";

    addMessage("assistant", "Document processed successfully. Displaying extracted content below:");
    addMessage("assistant", extractedText);

  } catch (err) {
    console.error(err);
    docStatus.innerText = "Upload failed ❌";
    addMessage("assistant", "Upload failed. Backend not reachable.");
  }
});


async function sendMessage() {
  const text = promptInput.value.trim();
  if (!text) return;

  addMessage("user", text);
  promptInput.value = "";

  chatHistory.push({ role: "user", content: text });

  // If you don't yet have chatbot backend:
  if (!extractedText) {
    addMessage("assistant", "Please upload a document first.");
    return;
  }

  // Temporary local response (until AI backend connected)
  addMessage("assistant", "I received your question. (AI backend not yet connected)");

  // Example payload for future chatbot backend:
  /*
  const res = await fetch("http://127.0.0.1:8000/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      document_text: extractedText,
      message: text,
      history: chatHistory
    })
  });

  const data = await res.json();
  addMessage("assistant", data.reply);
  chatHistory.push({ role: "assistant", content: data.reply });
  */
}
