console.log("Script loaded");

const chatWindow = document.getElementById("chatWindow");
const promptInput = document.getElementById("promptInput");
const sendBtn = document.getElementById("sendBtn");
const fileInput = document.getElementById("fileInput");

let documentId = null;
let chatHistory = [];

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerText = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

sendBtn.addEventListener("click", () => {
  console.log("Send clicked");
  sendMessage();
});

promptInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  addMessage("assistant", "Uploading document...");

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("http://localhost:8000/upload", {
      method: "POST",
      body: formData
    });

    const data = await res.json();
    documentId = data.document_id;

    addMessage("assistant", "Document uploaded successfully.");
  } catch (err) {
    addMessage("assistant", "Upload failed. Check backend.");
  }
});

async function sendMessage() {
  const text = promptInput.value.trim();
  if (!text) return;

  addMessage("user", text);
  chatHistory.push({ role: "user", content: text });
  promptInput.value = "";

  try {
    const res = await fetch("http://localhost:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        document_id: documentId, // may be null
        message: text,
        history: chatHistory
      })
    });

    const data = await res.json();

    addMessage("assistant", data.reply);
    chatHistory.push({ role: "assistant", content: data.reply });

  } catch (err) {
    addMessage("assistant", "Error contacting AI service.");
  }
}
